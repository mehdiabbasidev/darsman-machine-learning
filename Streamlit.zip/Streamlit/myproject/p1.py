import streamlit as st
import numpy as np
import pandas as pd
from PIL import Image

# st.title("Hello Streamlit")
# st.header("Hello Streamlit")
# st.write("Hello Streamlit")
# st.info("Hello Streamlit")
# st.success("Hello Streamlit")
# st.warning("Hello Streamlit")
# st.error("Hello Streamlit")


# st.markdown("### Hello Streamlit")
# st.markdown("<h2 style='color:blue;'>Hello Streamlit</h2>", unsafe_allow_html=True)

# st.latex(r"\int_0^\infty e^{-x^2} \, dx = \frac{\sqrt{\pi}}{2}")

# a=np.array([12,3,5,667,5,34,656,756,765,435,])
# st.write(a)


# df =pd.read_csv("data/iris.csv")
# st.dataframe(df)
# st.table(df)



# img1=Image.open("images/ai-master.webp")
# st.image(img1)



