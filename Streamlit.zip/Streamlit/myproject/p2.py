import streamlit as st
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image


# with st.form(key='my_form'):
#     name=st.text_input(label="Name")
#     password = st.text_input(label="Password", type="password")
#     age = st.number_input(label="Age", min_value=0, max_value=120, step=1)
#     gender=st.selectbox(label="Gender",options=["Male","Female"])
#     colors=st.multiselect(label="Colors",options=["Red","Green","Blue","Yellow","Pink","Black","White"])
#     address=st.text_area(label="Address")
#     avg=st.slider(label="Avg", min_value=0.0, max_value=20.0, step=0.1)
#     birthdate=st.date_input(label="Birth Date")
#     photo=st.file_uploader(label="Photo")
#     submit=st.form_submit_button("Register")


# if submit:
#     st.write(f'Name: {name}')
#     st.write(f'Password: {password}')
#     st.write(f'Age: {age}')
#     st.write(f'Gender: {gender}')
#     st.write(f'Colors: {colors}')
#     st.write(f'Address: {address}')
#     st.write(f'Avg: {avg}')
#     st.write(f'Birth Date: {birthdate}')
#     img1=Image.open(photo)
#     st.image(img1)



# st.sidebar.header("Sidbar")
# st.sidebar.markdown("### Item1")
# st.sidebar.markdown("### Item2")
# st.sidebar.markdown("### Item3")
# st.sidebar.markdown("### Item4")
# st.sidebar.button("Test Button")



# data = np.random.rand(20)
# fig, ax = plt.subplots()
# ax.plot(data, label='Value')
# ax.set_xlabel('Index')
# ax.set_ylabel('Value')
# ax.set_title('Line Chart')
# ax.legend()
# st.pyplot(fig)
